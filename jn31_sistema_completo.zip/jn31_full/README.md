# Sistema de Gestión de Recursos Materiales
## J&N31 A1 Importaciones, C.A. — Maturín, Estado Monagas

Sistema web completo con arquitectura cliente-servidor para gestionar solicitudes de compra, cotizaciones, aprobaciones de recursos y proveedores, con control de acceso basado en roles (RBAC).

---

## Arquitectura del Sistema

```
┌─────────────────┐       HTTP/JSON        ┌─────────────────┐       SQL        ┌─────────────────┐
│   FRONTEND      │ ◄───────────────────►  │    BACKEND      │ ◄──────────────► │   BASE DE DATOS │
│  React + HTML   │   http://localhost:3001 │  Node.js + API  │    mysql2        │     MySQL       │
│                 │                        │    Express      │                  │                 │
└─────────────────┘                        └─────────────────┘                  └─────────────────┘
```

**Tecnologías:**
- Frontend: React 18 + Tailwind CSS (CDN)
- Backend: Node.js + Express 4 + JWT + Bcrypt
- Base de datos: MySQL 5.7+/8.0+ (compatible con XAMPP/WAMP)
- Archivos: Multer (subida) + PDFKit (generación de reportes)

---

## Requisitos Previos

Antes de instalar el sistema debes tener:

1. **XAMPP, WAMP o MySQL Server** instalado y corriendo (para la base de datos)
   - Descargar XAMPP: https://www.apachefriends.org/
2. **Node.js 18 o superior** instalado
   - Descargar: https://nodejs.org/
3. **Un navegador web moderno** (Chrome, Edge, Firefox)

Para verificar que tienes Node.js instalado, abre una terminal y ejecuta:
```bash
node --version
npm --version
```

---

## Instalación Paso a Paso

### 1. Crear la base de datos MySQL

**Opción A: usando phpMyAdmin (XAMPP)**
1. Inicia XAMPP y activa los módulos **Apache** y **MySQL**.
2. Abre `http://localhost/phpmyadmin` en tu navegador.
3. Haz clic en la pestaña **"SQL"**.
4. Abre el archivo `database/schema.sql` con un editor de texto, copia TODO su contenido y pégalo en el cuadro de SQL.
5. Presiona **"Continuar"**. Deberías ver el mensaje `✓ Base de datos jn31_importaciones creada exitosamente`.

**Opción B: por línea de comandos**
```bash
cd database
mysql -u root -p < schema.sql
```
(deja en blanco la contraseña si usas XAMPP por defecto)

### 2. Instalar el backend

```bash
cd backend
npm install
```

Esto instalará todas las dependencias listadas en `package.json` (Express, MySQL, JWT, Bcrypt, PDFKit, etc.).

### 3. Configurar las credenciales de la base de datos

Abre el archivo `backend/.env` y ajusta si es necesario:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=          # por defecto vacío en XAMPP
DB_NAME=jn31_importaciones
PORT=3001
```

> **Importante**: Si tu MySQL tiene una contraseña, ponla en `DB_PASSWORD`.

### 4. Generar los hashes de las contraseñas iniciales

Las contraseñas se guardan con **bcrypt** (encriptadas). Ejecuta una sola vez:

```bash
npm run init-passwords
```

Esto reemplaza los placeholders del SQL con hashes reales de la contraseña `1234`.

### 5. Iniciar el servidor backend

```bash
npm start
```

Deberías ver:
```
═══════════════════════════════════════════════════════════════
  SISTEMA DE GESTIÓN DE RECURSOS MATERIALES
  J&N31 A1 IMPORTACIONES, C.A. - Maturín, Estado Monagas
═══════════════════════════════════════════════════════════════

✓ Conexión a MySQL establecida: jn31_importaciones
✓ Servidor API corriendo en: http://localhost:3001
```

### 6. Abrir el frontend

Tienes **dos opciones**:

**Opción A (recomendada)**: el backend ya sirve el frontend automáticamente.
- Abre `http://localhost:3001` en tu navegador.

**Opción B**: servir el frontend con otro servidor (Live Server de VSCode, http-server, etc.)
- Abre `frontend/index.html` con Live Server en VSCode.
- Asegúrate de que el backend esté corriendo en el puerto 3001.

---

## Usuarios de Prueba

Todos los usuarios tienen la contraseña `1234`:

| Rol | Usuario | Acceso |
|---|---|---|
| SuperUsuario | `agomez@gmail.com` | Todos los módulos excepto *Recursos* y *Elaborar Cotización* |
| Gerente de Proyectos | `nairodriguez@gmail.com` | Solicitudes, Cotización, Proveedores |
| Director / Presidente | `armandohz@gmail.com` | Exclusivo: *Aprobación de Recursos* |
| Gerente de Operaciones | `perezjose@gmail.com` | Solicitudes completo |
| Especialista de Compra | `alopez12@gmail.com` | Similar a Gerente de Proyectos |
| Personal Designado | `ana.rondon@gmail.com` | Solo elaborar solicitud |

---

## Estructura del Proyecto

```
jn31_importaciones/
├── database/
│   └── schema.sql                 ← Script SQL del modelo relacional
│
├── backend/
│   ├── package.json               ← Dependencias Node.js
│   ├── .env                       ← Variables de entorno (credenciales)
│   ├── .env.example               ← Plantilla de configuración
│   ├── server.js                  ← Servidor Express principal
│   ├── config/
│   │   └── db.js                  ← Pool de conexiones MySQL
│   ├── middleware/
│   │   └── auth.js                ← JWT + Control de roles (RBAC)
│   ├── scripts/
│   │   └── seed-passwords.js      ← Genera hashes bcrypt iniciales
│   ├── routes/
│   │   ├── auth.js                ← Login, logout, recuperar contraseña
│   │   ├── usuarios.js            ← CRUD de usuarios
│   │   ├── solicitudes.js         ← CRUD de solicitudes + subida de archivos
│   │   ├── cotizaciones.js        ← CRUD + aprobación + PDF
│   │   ├── recursos.js            ← Aprobación del Presidente
│   │   ├── proveedores.js         ← CRUD de proveedores
│   │   └── notificaciones.js      ← Notificaciones del sistema
│   └── uploads/                   ← Archivos subidos (auto-generado)
│
└── frontend/
    └── index.html                 ← Aplicación React completa
```

---

## Endpoints Principales de la API

Una lista completa está disponible en `http://localhost:3001/api` una vez iniciado el servidor.

### Autenticación
| Método | Endpoint | Descripción |
|---|---|---|
| POST | `/api/auth/login` | Iniciar sesión (retorna JWT) |
| GET | `/api/auth/me` | Obtener datos del usuario actual |
| POST | `/api/auth/logout` | Cerrar sesión |
| POST | `/api/auth/forgot-password` | Solicitar recuperación |

### Usuarios (solo SuperUsuario)
| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/api/usuarios` | Listar usuarios |
| POST | `/api/usuarios` | Crear usuario |
| PUT | `/api/usuarios/:cedula` | Actualizar usuario |
| DELETE | `/api/usuarios/:cedula` | Eliminar usuario |

### Solicitudes
| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/api/solicitudes` | Listar solicitudes |
| POST | `/api/solicitudes` | Crear solicitud (soporta archivo adjunto) |
| PUT | `/api/solicitudes/:id` | Actualizar solicitud |
| DELETE | `/api/solicitudes/:id` | Eliminar solicitud |

### Cotizaciones
| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/api/cotizaciones` | Listar cotizaciones |
| POST | `/api/cotizaciones` | Elaborar cotización con análisis comparativo |
| POST | `/api/cotizaciones/:id/aprobar` | Aprobar cotización |
| GET | `/api/cotizaciones/:id/pdf` | **Descargar PDF del análisis comparativo** |

### Recursos (solo Director / Presidente)
| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/api/recursos` | Listar cotizaciones pendientes de aprobación |
| POST | `/api/recursos/:id/aprobar` | Aprobar recurso |
| POST | `/api/recursos/:id/rechazar` | Rechazar recurso |

---

## Flujo de Trabajo del Sistema

```
1. CREAR SOLICITUD          → Estado: "Pendiente"
     ↓
2. ELABORAR COTIZACIÓN      → Estado solicitud: "En Cotización"
   (análisis comparativo de 3 proveedores, seleccionar uno)
     ↓
3. APROBAR COTIZACIÓN       → Estado solicitud: "En Aprobación"
   (Gerente de Proyectos)
     ↓
4. APROBAR RECURSOS         → Estado solicitud: "Aprobado" o "Rechazado"
   (Director/Presidente)
     ↓
5. DESCARGAR PDF del análisis comparativo
```

---

## Seguridad Implementada

- **Autenticación JWT** con expiración de 8 horas
- **Contraseñas encriptadas con bcrypt** (rounds=10)
- **Control de acceso basado en roles (RBAC)** verificado en servidor
- **Validación de entradas** en cada endpoint
- **Auditoría completa** de acciones (tabla `auditoria`)
- **Transacciones SQL** para operaciones críticas (elaborar cotización, aprobar, rechazar)
- **CORS configurable** por entorno
- **Protección contra inyección SQL** con queries parametrizadas

---

## Para Defensa de Tesis — Puntos Clave

1. **Arquitectura de 3 capas** (cliente, servidor, base de datos) completamente desacoplada
2. **API REST** siguiendo estándares HTTP (GET, POST, PUT, DELETE)
3. **Base de datos relacional normalizada** en 3FN con 9 tablas y 3 vistas
4. **Modelo Entidad-Relación** puedes generarlo abriendo el schema en MySQL Workbench → *Reverse Engineer*
5. **Seguridad** con JWT + bcrypt (buenas prácticas actuales)
6. **Auditoría** para trazabilidad (tabla `auditoria` registra toda acción)
7. **Control de acceso por rol (RBAC)** validado en servidor, no solo en interfaz
8. **Generación de reportes PDF** con PDFKit
9. **Gestión de archivos** con Multer (subida de PDFs, imágenes)

---

## Solución de Problemas

**"No se puede conectar a MySQL"**
- Verifica que XAMPP/MySQL esté corriendo.
- Revisa las credenciales en `backend/.env`.
- Asegúrate de haber ejecutado `schema.sql`.

**"Error al hacer login"**
- Ejecuta `npm run init-passwords` en la carpeta backend.

**"CORS error" en el navegador**
- Asegúrate de que el backend esté corriendo en `localhost:3001`.
- Si el frontend está en otro puerto, agrégalo a `CORS_ORIGIN` en `.env`.

**"Cannot find module ..."**
- Ejecuta `npm install` dentro de la carpeta `backend`.

---

## Despliegue en Producción

Para alojar en un servidor real:

1. **Servidor**: compra un VPS (DigitalOcean, AWS, Azure) o usa un hosting con Node.js (Render, Railway, Fly.io).
2. **Dominio**: apunta el dominio al IP del servidor.
3. **Base de datos**: instala MySQL en el servidor o usa uno gestionado (PlanetScale, AWS RDS).
4. **Variables**: configura `.env` con las credenciales de producción y un `JWT_SECRET` largo y aleatorio.
5. **Proceso**: usa `pm2` para mantener el servidor corriendo: `npm install -g pm2 && pm2 start server.js`.
6. **Reverse proxy**: configura Nginx o Apache para HTTPS con Let's Encrypt.

---

© 2026 — Tesis: Sistema de Información para la Gestión de Recursos Materiales en J&N31 A1 Importaciones, C.A., Maturín, Estado Monagas
