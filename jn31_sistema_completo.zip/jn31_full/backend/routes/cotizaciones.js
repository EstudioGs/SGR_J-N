// ============================================================
// RUTAS: Cotizaciones (CRUD) + Exportación a PDF
// ============================================================

const express = require('express');
const PDFDocument = require('pdfkit');
const router = express.Router();
const { pool } = require('../config/db');
const { authenticateToken, requireAction } = require('../middleware/auth');

router.use(authenticateToken);

// Generar siguiente código de cotización
async function getNextCode() {
    const [rows] = await pool.query('SELECT MAX(CAST(SUBSTRING(codigo, 5) AS UNSIGNED)) AS max FROM cotizaciones');
    const next = (rows[0].max || 30) + 1;
    return 'COT-' + String(next).padStart(5, '0');
}

// GET /api/cotizaciones - Listar con detalle completo
router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT c.*,
                   s.codigo AS codigo_solicitud,
                   p.codigo AS codigo_proveedor,
                   p.nombre AS nombre_proveedor,
                   u.nombre AS elaborador
            FROM cotizaciones c
            INNER JOIN solicitudes s ON c.id_solicitud = s.id_solicitud
            LEFT JOIN proveedores p ON c.id_proveedor_seleccionado = p.id_proveedor
            LEFT JOIN usuarios u ON c.cedula_elaborador = u.cedula
            ORDER BY c.fecha_cotizacion DESC, c.id_cotizacion DESC
        `);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al listar cotizaciones' });
    }
});

// GET /api/cotizaciones/stats
router.get('/stats', async (req, res) => {
    try {
        const [stats] = await pool.query(`
            SELECT 
                SUM(CASE WHEN estado='Pendiente' THEN 1 ELSE 0 END) AS pendientes,
                SUM(CASE WHEN estado='En Proceso' THEN 1 ELSE 0 END) AS en_proceso,
                SUM(CASE WHEN estado='Aprobada' THEN 1 ELSE 0 END) AS aprobados,
                COUNT(*) AS total
            FROM cotizaciones
        `);
        res.json(stats[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener estadísticas' });
    }
});

// GET /api/cotizaciones/:id - Detalle con análisis comparativo
router.get('/:id', async (req, res) => {
    try {
        const [cotRows] = await pool.query(`
            SELECT c.*, s.codigo AS codigo_solicitud, s.descripcion AS desc_solicitud,
                   p.codigo AS codigo_proveedor, p.nombre AS nombre_proveedor,
                   u.nombre AS elaborador
            FROM cotizaciones c
            INNER JOIN solicitudes s ON c.id_solicitud = s.id_solicitud
            LEFT JOIN proveedores p ON c.id_proveedor_seleccionado = p.id_proveedor
            LEFT JOIN usuarios u ON c.cedula_elaborador = u.cedula
            WHERE c.codigo = ? OR c.id_cotizacion = ?
        `, [req.params.id, req.params.id]);
        
        if (cotRows.length === 0) return res.status(404).json({ error: 'Cotización no encontrada' });
        
        const cot = cotRows[0];
        // Obtener detalles comparativos
        const [detalles] = await pool.query(`
            SELECT cd.*, p.codigo AS codigo_proveedor, p.nombre AS nombre_proveedor
            FROM cotizacion_detalles cd
            INNER JOIN proveedores p ON cd.id_proveedor = p.id_proveedor
            WHERE cd.id_cotizacion = ?
            ORDER BY cd.id_detalle
        `, [cot.id_cotizacion]);

        cot.detalles = detalles;
        res.json(cot);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al obtener cotización' });
    }
});

// POST /api/cotizaciones - Crear (elaborar)
router.post('/', requireAction('cotizacion', 'elaborar'), async (req, res) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();
        
        const { id_solicitud, descripcion, memo_justificativo, detalles } = req.body;
        
        if (!id_solicitud || !descripcion || !Array.isArray(detalles) || detalles.length === 0) {
            return res.status(400).json({ error: 'Datos incompletos (solicitud, descripción y detalles son obligatorios)' });
        }
        
        const seleccionado = detalles.find(d => d.seleccionado);
        if (!seleccionado) {
            return res.status(400).json({ error: 'Debe seleccionar un proveedor ganador' });
        }

        const codigo = await getNextCode();

        const [result] = await conn.query(`
            INSERT INTO cotizaciones (codigo, id_solicitud, descripcion, id_proveedor_seleccionado, total_usd, memo_justificativo, estado, cedula_elaborador)
            VALUES (?, ?, ?, ?, ?, ?, 'Pendiente', ?)
        `, [codigo, id_solicitud, descripcion, seleccionado.id_proveedor, seleccionado.precio_usd, memo_justificativo, req.user.cedula]);

        const id_cotizacion = result.insertId;

        // Insertar detalles comparativos
        for (const d of detalles) {
            await conn.query(`
                INSERT INTO cotizacion_detalles (id_cotizacion, id_proveedor, producto, precio_usd, tiempo_entrega, seleccionado)
                VALUES (?, ?, ?, ?, ?, ?)
            `, [id_cotizacion, d.id_proveedor, d.producto, d.precio_usd, d.tiempo_entrega, !!d.seleccionado]);
        }

        // Actualizar estado de la solicitud a "En Cotización"
        await conn.query('UPDATE solicitudes SET estado = ? WHERE id_solicitud = ?', ['En Cotización', id_solicitud]);

        // Auditoría
        await conn.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'CREAR', 'cotizaciones', ?, ?, ?)
        `, [req.user.cedula, codigo, `Elaboró cotización ${descripcion}`, req.ip]);

        await conn.commit();

        const [nueva] = await pool.query(`SELECT * FROM vw_cotizaciones_detalle WHERE codigo = ?`, [codigo]);
        res.status(201).json(nueva[0]);
    } catch (err) {
        await conn.rollback();
        console.error(err);
        res.status(500).json({ error: 'Error al crear cotización' });
    } finally {
        conn.release();
    }
});

// POST /api/cotizaciones/:id/aprobar - Aprobar cotización
router.post('/:id/aprobar', requireAction('cotizacion', 'aprobar'), async (req, res) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();
        
        const [cotRows] = await conn.query('SELECT * FROM cotizaciones WHERE codigo = ? OR id_cotizacion = ?', [req.params.id, req.params.id]);
        if (cotRows.length === 0) {
            await conn.rollback();
            return res.status(404).json({ error: 'Cotización no encontrada' });
        }

        const cot = cotRows[0];
        await conn.query('UPDATE cotizaciones SET estado = ? WHERE id_cotizacion = ?', ['Aprobada', cot.id_cotizacion]);
        // La solicitud pasa a "En Aprobación" (esperando al Presidente)
        await conn.query('UPDATE solicitudes SET estado = ? WHERE id_solicitud = ?', ['En Aprobación', cot.id_solicitud]);

        // Notificar al Director Regional / Presidente
        await conn.query(`
            INSERT INTO notificaciones (id_rol_destinatario, tipo, mensaje)
            SELECT id_rol, 'warning', ? FROM roles WHERE nombre = 'Director Regional / Presidente'
        `, [`Cotización ${cot.codigo} requiere aprobación de recursos`]);

        await conn.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'APROBAR', 'cotizaciones', ?, ?, ?)
        `, [req.user.cedula, cot.codigo, `Aprobó cotización y envió a aprobación de recursos`, req.ip]);

        await conn.commit();
        res.json({ message: 'Cotización aprobada. Enviada al Presidente para aprobación de recursos.' });
    } catch (err) {
        await conn.rollback();
        console.error(err);
        res.status(500).json({ error: 'Error al aprobar cotización' });
    } finally {
        conn.release();
    }
});

// GET /api/cotizaciones/:id/pdf - Descargar PDF de la cotización
router.get('/:id/pdf', async (req, res) => {
    try {
        const [cotRows] = await pool.query(`
            SELECT c.*, s.codigo AS codigo_solicitud, s.descripcion AS desc_solicitud,
                   p.nombre AS nombre_proveedor, u.nombre AS elaborador
            FROM cotizaciones c
            INNER JOIN solicitudes s ON c.id_solicitud = s.id_solicitud
            LEFT JOIN proveedores p ON c.id_proveedor_seleccionado = p.id_proveedor
            LEFT JOIN usuarios u ON c.cedula_elaborador = u.cedula
            WHERE c.codigo = ? OR c.id_cotizacion = ?
        `, [req.params.id, req.params.id]);
        
        if (cotRows.length === 0) return res.status(404).json({ error: 'Cotización no encontrada' });
        const cot = cotRows[0];

        const [detalles] = await pool.query(`
            SELECT cd.*, p.nombre AS nombre_proveedor
            FROM cotizacion_detalles cd
            INNER JOIN proveedores p ON cd.id_proveedor = p.id_proveedor
            WHERE cd.id_cotizacion = ?
        `, [cot.id_cotizacion]);

        // Generar PDF con PDFKit
        const doc = new PDFDocument({ size: 'A4', margin: 50 });
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="${cot.codigo}.pdf"`);
        doc.pipe(res);

        // Encabezado
        doc.fontSize(20).fillColor('#0d47a1').text('J&N31 A1 IMPORTACIONES, C.A.', { align: 'center' });
        doc.fontSize(10).fillColor('#666').text('Maturín, Estado Monagas', { align: 'center' });
        doc.moveDown();
        doc.fontSize(16).fillColor('#000').text('COTIZACIÓN DE COMPRA', { align: 'center' });
        doc.moveDown(1.5);

        // Información general
        doc.fontSize(11).fillColor('#000');
        const leftCol = 50, rightCol = 320;
        let y = doc.y;
        doc.font('Helvetica-Bold').text('Código:', leftCol, y).font('Helvetica').text(cot.codigo, leftCol + 80, y);
        doc.font('Helvetica-Bold').text('Fecha:', rightCol, y).font('Helvetica').text(new Date(cot.fecha_cotizacion).toLocaleDateString('es-VE'), rightCol + 80, y);
        y += 18;
        doc.font('Helvetica-Bold').text('Solicitud:', leftCol, y).font('Helvetica').text('#' + cot.codigo_solicitud, leftCol + 80, y);
        doc.font('Helvetica-Bold').text('Estado:', rightCol, y).font('Helvetica').text(cot.estado, rightCol + 80, y);
        y += 18;
        doc.font('Helvetica-Bold').text('Descripción:', leftCol, y).font('Helvetica').text(cot.descripcion, leftCol + 80, y);
        y += 18;
        doc.font('Helvetica-Bold').text('Elaborado por:', leftCol, y).font('Helvetica').text(cot.elaborador || '—', leftCol + 80, y);
        doc.moveDown(2);

        // Tabla de análisis comparativo
        doc.fontSize(13).font('Helvetica-Bold').fillColor('#0d47a1').text('ANÁLISIS COMPARATIVO DE PROVEEDORES', { underline: true });
        doc.moveDown(0.5);
        doc.fontSize(10).fillColor('#000');

        // Cabeceras de tabla
        const tableTop = doc.y + 5;
        const cols = { prov: 50, prod: 170, prec: 310, ent: 400, sel: 490 };
        doc.font('Helvetica-Bold').fillColor('#fff');
        doc.rect(50, tableTop, 500, 22).fill('#0d47a1');
        doc.fillColor('#fff').text('Proveedor', cols.prov + 5, tableTop + 6);
        doc.text('Producto', cols.prod + 5, tableTop + 6);
        doc.text('Precio (USD)', cols.prec + 5, tableTop + 6);
        doc.text('Entrega', cols.ent + 5, tableTop + 6);
        doc.text('Selec.', cols.sel + 5, tableTop + 6);

        let rowY = tableTop + 22;
        doc.font('Helvetica').fillColor('#000');
        detalles.forEach((d, i) => {
            const bg = d.seleccionado ? '#d1fae5' : (i % 2 === 0 ? '#f9fafb' : '#fff');
            doc.rect(50, rowY, 500, 22).fill(bg);
            doc.fillColor('#000').text(d.nombre_proveedor, cols.prov + 5, rowY + 6, { width: 110 });
            doc.text(d.producto, cols.prod + 5, rowY + 6, { width: 130 });
            doc.text('$' + parseFloat(d.precio_usd).toFixed(2), cols.prec + 5, rowY + 6);
            doc.text(d.tiempo_entrega, cols.ent + 5, rowY + 6);
            doc.text(d.seleccionado ? '✓' : '', cols.sel + 15, rowY + 6);
            rowY += 22;
        });
        doc.y = rowY + 10;
        doc.moveDown();

        // Total
        doc.fontSize(14).font('Helvetica-Bold').fillColor('#0d47a1');
        doc.text(`TOTAL SELECCIONADO: $${parseFloat(cot.total_usd).toFixed(2)} USD`, { align: 'right' });
        doc.moveDown(1.5);

        // MEMO Justificativo
        doc.fontSize(12).font('Helvetica-Bold').fillColor('#000').text('MEMO JUSTIFICATIVO:');
        doc.moveDown(0.3);
        doc.fontSize(11).font('Helvetica').fillColor('#333').text(cot.memo_justificativo || 'Sin observaciones.', {
            align: 'justify',
            width: 500
        });

        // Pie
        doc.fontSize(8).fillColor('#999').text(
            `Documento generado el ${new Date().toLocaleString('es-VE')} por el Sistema de Gestión J&N31 A1 Importaciones, C.A.`,
            50, doc.page.height - 60, { align: 'center', width: 500 }
        );

        doc.end();
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al generar PDF' });
    }
});

// DELETE /api/cotizaciones/:id
router.delete('/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM cotizaciones WHERE codigo = ? OR id_cotizacion = ?', [req.params.id, req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Cotización no encontrada' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'ELIMINAR', 'cotizaciones', ?, ?, ?)
        `, [req.user.cedula, req.params.id, `Eliminó cotización`, req.ip]);

        res.json({ message: 'Cotización eliminada' });
    } catch (err) {
        res.status(500).json({ error: 'Error al eliminar cotización' });
    }
});

module.exports = router;
