// ============================================================
// RUTAS: Usuarios (CRUD completo - solo SuperUsuario)
// ============================================================

const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const { pool } = require('../config/db');
const { authenticateToken, requireAction } = require('../middleware/auth');

// Todas las rutas requieren autenticación
router.use(authenticateToken);

// GET /api/usuarios - Listar todos los usuarios
router.get('/', requireAction('usuarios', 'listar'), async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM vw_usuarios_detalle ORDER BY fecha_creacion DESC');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al listar usuarios' });
    }
});

// GET /api/usuarios/roles - Listar todos los roles
router.get('/roles', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM roles ORDER BY id_rol');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Error al listar roles' });
    }
});

// GET /api/usuarios/stats - Estadísticas (activos, admins, total)
router.get('/stats', requireAction('usuarios', 'listar'), async (req, res) => {
    try {
        const [stats] = await pool.query(`
            SELECT 
                (SELECT COUNT(*) FROM usuarios WHERE estado='Activo') AS activos,
                (SELECT COUNT(*) FROM usuarios u JOIN roles r ON u.id_rol=r.id_rol WHERE r.nombre='SuperUsuario') AS administradores,
                (SELECT COUNT(*) FROM usuarios) AS total
        `);
        res.json(stats[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener estadísticas' });
    }
});

// GET /api/usuarios/:cedula - Obtener un usuario específico
router.get('/:cedula', requireAction('usuarios', 'ver'), async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM vw_usuarios_detalle WHERE cedula = ?', [req.params.cedula]);
        if (rows.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener usuario' });
    }
});

// POST /api/usuarios - Crear usuario
router.post('/', requireAction('usuarios', 'agregar'), async (req, res) => {
    try {
        const { cedula, nombre, nombre_completo, usuario, password, telefono, id_rol, estado } = req.body;
        if (!cedula || !nombre || !usuario || !password || !id_rol) {
            return res.status(400).json({ error: 'Faltan campos obligatorios' });
        }

        // Verificar si ya existe
        const [exists] = await pool.query('SELECT cedula FROM usuarios WHERE cedula = ? OR usuario = ?', [cedula, usuario]);
        if (exists.length > 0) {
            return res.status(409).json({ error: 'La cédula o el usuario ya existen' });
        }

        const hash = await bcrypt.hash(password, 10);
        await pool.query(`
            INSERT INTO usuarios (cedula, nombre, nombre_completo, usuario, password_hash, telefono, id_rol, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [cedula, nombre, nombre_completo || nombre, usuario, hash, telefono, id_rol, estado || 'Activo']);

        // Auditoría
        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'CREAR', 'usuarios', ?, ?, ?)
        `, [req.user.cedula, cedula, `Creó usuario ${nombre}`, req.ip]);

        const [nuevo] = await pool.query('SELECT * FROM vw_usuarios_detalle WHERE cedula = ?', [cedula]);
        res.status(201).json(nuevo[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al crear usuario' });
    }
});

// PUT /api/usuarios/:cedula - Actualizar usuario
router.put('/:cedula', requireAction('usuarios', 'editar'), async (req, res) => {
    try {
        const { nombre, nombre_completo, usuario, password, telefono, id_rol, estado } = req.body;
        
        let sql, params;
        if (password && password.length > 0) {
            const hash = await bcrypt.hash(password, 10);
            sql = `UPDATE usuarios SET nombre=?, nombre_completo=?, usuario=?, password_hash=?, telefono=?, id_rol=?, estado=? WHERE cedula=?`;
            params = [nombre, nombre_completo, usuario, hash, telefono, id_rol, estado, req.params.cedula];
        } else {
            sql = `UPDATE usuarios SET nombre=?, nombre_completo=?, usuario=?, telefono=?, id_rol=?, estado=? WHERE cedula=?`;
            params = [nombre, nombre_completo, usuario, telefono, id_rol, estado, req.params.cedula];
        }

        const [result] = await pool.query(sql, params);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Usuario no encontrado' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'EDITAR', 'usuarios', ?, ?, ?)
        `, [req.user.cedula, req.params.cedula, `Editó usuario ${nombre}`, req.ip]);

        const [updated] = await pool.query('SELECT * FROM vw_usuarios_detalle WHERE cedula = ?', [req.params.cedula]);
        res.json(updated[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al actualizar usuario' });
    }
});

// DELETE /api/usuarios/:cedula - Eliminar usuario
router.delete('/:cedula', requireAction('usuarios', 'eliminar'), async (req, res) => {
    try {
        // No permitir auto-eliminación
        if (req.params.cedula === req.user.cedula) {
            return res.status(400).json({ error: 'No puede eliminar su propio usuario' });
        }

        const [result] = await pool.query('DELETE FROM usuarios WHERE cedula = ?', [req.params.cedula]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Usuario no encontrado' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'ELIMINAR', 'usuarios', ?, ?, ?)
        `, [req.user.cedula, req.params.cedula, `Eliminó usuario`, req.ip]);

        res.json({ message: 'Usuario eliminado correctamente' });
    } catch (err) {
        console.error(err);
        if (err.code === 'ER_ROW_IS_REFERENCED_2') {
            return res.status(409).json({ error: 'No se puede eliminar: el usuario tiene registros vinculados' });
        }
        res.status(500).json({ error: 'Error al eliminar usuario' });
    }
});

module.exports = router;
