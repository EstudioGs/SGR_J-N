// ============================================================
// RUTAS: Notificaciones
// ============================================================

const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

// GET /api/notificaciones - Listar notificaciones del usuario actual
router.get('/', async (req, res) => {
    try {
        // Obtener id_rol del usuario actual
        const [userRol] = await pool.query('SELECT id_rol FROM usuarios WHERE cedula = ?', [req.user.cedula]);
        const id_rol = userRol[0]?.id_rol;

        const [rows] = await pool.query(`
            SELECT * FROM notificaciones 
            WHERE cedula_destinatario = ? 
               OR (id_rol_destinatario = ? AND cedula_destinatario IS NULL)
            ORDER BY fecha_creacion DESC
            LIMIT 20
        `, [req.user.cedula, id_rol]);
        
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al listar notificaciones' });
    }
});

// PATCH /api/notificaciones/:id/leer - Marcar como leída
router.patch('/:id/leer', async (req, res) => {
    try {
        await pool.query('UPDATE notificaciones SET leida = TRUE WHERE id_notificacion = ?', [req.params.id]);
        res.json({ message: 'Notificación marcada como leída' });
    } catch (err) {
        res.status(500).json({ error: 'Error al actualizar notificación' });
    }
});

module.exports = router;
