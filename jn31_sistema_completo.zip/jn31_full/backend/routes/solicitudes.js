// ============================================================
// RUTAS: Solicitudes (CRUD) con soporte de subida de archivos
// ============================================================

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const router = express.Router();
const { pool } = require('../config/db');
const { authenticateToken, requireAction } = require('../middleware/auth');

// Configuración de multer para subida de archivos
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = path.join(__dirname, '..', 'uploads', 'solicitudes');
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, `sol-${unique}${ext}`);
    }
});
const upload = multer({
    storage,
    limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10485760 },
    fileFilter: (req, file, cb) => {
        const allowed = /pdf|jpe?g|png|doc|docx|xls|xlsx/;
        const ok = allowed.test(path.extname(file.originalname).toLowerCase());
        cb(ok ? null : new Error('Tipo de archivo no permitido'), ok);
    }
});

router.use(authenticateToken);

// Generar siguiente código de solicitud
async function getNextCode() {
    const [rows] = await pool.query('SELECT MAX(CAST(codigo AS UNSIGNED)) AS max FROM solicitudes');
    const next = (rows[0].max || 230) + 1;
    return String(next).padStart(5, '0');
}

// GET /api/solicitudes - Listar
router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM vw_solicitudes_detalle ORDER BY fecha_solicitud DESC, id_solicitud DESC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Error al listar solicitudes' });
    }
});

// GET /api/solicitudes/stats - Estadísticas
router.get('/stats', async (req, res) => {
    try {
        const [stats] = await pool.query(`
            SELECT 
                SUM(CASE WHEN estado='Pendiente' THEN 1 ELSE 0 END) AS pendientes,
                SUM(CASE WHEN estado='En Cotización' THEN 1 ELSE 0 END) AS en_cotizacion,
                SUM(CASE WHEN estado='En Aprobación' THEN 1 ELSE 0 END) AS en_aprobacion,
                SUM(CASE WHEN estado='Aprobado' THEN 1 ELSE 0 END) AS aprobados,
                SUM(CASE WHEN estado='Rechazado' THEN 1 ELSE 0 END) AS rechazados,
                COUNT(*) AS total
            FROM solicitudes
        `);
        res.json(stats[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener estadísticas' });
    }
});

// GET /api/solicitudes/:id - Detalle
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM vw_solicitudes_detalle WHERE codigo = ? OR id_solicitud = ?', [req.params.id, req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Solicitud no encontrada' });
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener solicitud' });
    }
});

// POST /api/solicitudes - Crear
router.post('/', requireAction('solicitudes', 'agregar'), upload.single('archivo'), async (req, res) => {
    try {
        const { descripcion, memo_justificativo } = req.body;
        if (!descripcion) {
            return res.status(400).json({ error: 'La descripción es obligatoria' });
        }

        const codigo = await getNextCode();
        const archivo = req.file ? `uploads/solicitudes/${req.file.filename}` : null;

        const [result] = await pool.query(`
            INSERT INTO solicitudes (codigo, descripcion, memo_justificativo, cedula_solicitante, estado, archivo_adjunto)
            VALUES (?, ?, ?, ?, 'Pendiente', ?)
        `, [codigo, descripcion, memo_justificativo || '', req.user.cedula, archivo]);

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'CREAR', 'solicitudes', ?, ?, ?)
        `, [req.user.cedula, codigo, `Creó solicitud ${descripcion}`, req.ip]);

        // Notificación para usuarios que pueden cotizar
        await pool.query(`
            INSERT INTO notificaciones (id_rol_destinatario, tipo, mensaje)
            SELECT id_rol, 'info', ? FROM roles WHERE nombre IN ('Gerente de Proyectos','Especialista de Compra')
        `, [`Nueva solicitud #${codigo}: ${descripcion}`]);

        const [nueva] = await pool.query('SELECT * FROM vw_solicitudes_detalle WHERE id_solicitud = ?', [result.insertId]);
        res.status(201).json(nueva[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al crear solicitud' });
    }
});

// PUT /api/solicitudes/:id - Actualizar
router.put('/:id', requireAction('solicitudes', 'editar'), upload.single('archivo'), async (req, res) => {
    try {
        const { descripcion, memo_justificativo, estado } = req.body;
        
        let archivoSql = '', archivoParam = [];
        if (req.file) {
            archivoSql = ', archivo_adjunto = ?';
            archivoParam = [`uploads/solicitudes/${req.file.filename}`];
        }

        const [result] = await pool.query(`
            UPDATE solicitudes 
            SET descripcion=?, memo_justificativo=?, estado=?${archivoSql}
            WHERE codigo=? OR id_solicitud=?
        `, [descripcion, memo_justificativo, estado, ...archivoParam, req.params.id, req.params.id]);

        if (result.affectedRows === 0) return res.status(404).json({ error: 'Solicitud no encontrada' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'EDITAR', 'solicitudes', ?, ?, ?)
        `, [req.user.cedula, req.params.id, `Editó solicitud`, req.ip]);

        const [upd] = await pool.query('SELECT * FROM vw_solicitudes_detalle WHERE codigo = ? OR id_solicitud = ?', [req.params.id, req.params.id]);
        res.json(upd[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al actualizar solicitud' });
    }
});

// DELETE /api/solicitudes/:id - Eliminar
router.delete('/:id', requireAction('solicitudes', 'eliminar'), async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM solicitudes WHERE codigo = ? OR id_solicitud = ?', [req.params.id, req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Solicitud no encontrada' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'ELIMINAR', 'solicitudes', ?, ?, ?)
        `, [req.user.cedula, req.params.id, `Eliminó solicitud`, req.ip]);

        res.json({ message: 'Solicitud eliminada correctamente' });
    } catch (err) {
        res.status(500).json({ error: 'Error al eliminar solicitud' });
    }
});

module.exports = router;
