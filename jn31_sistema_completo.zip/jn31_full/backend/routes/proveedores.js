// ============================================================
// RUTAS: Proveedores (CRUD)
// ============================================================

const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { authenticateToken, requireModule, requireAction } = require('../middleware/auth');

router.use(authenticateToken);
router.use(requireModule('proveedores'));

// GET /api/proveedores - Listar
router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM proveedores WHERE activo = TRUE ORDER BY codigo');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Error al listar proveedores' });
    }
});

// GET /api/proveedores/:id - Detalle
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM proveedores WHERE codigo = ? OR id_proveedor = ?', [req.params.id, req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Proveedor no encontrado' });
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener proveedor' });
    }
});

// POST /api/proveedores - Crear
router.post('/', async (req, res) => {
    try {
        const { codigo, nombre, contacto_principal, telefono, email, direccion } = req.body;
        if (!codigo || !nombre) return res.status(400).json({ error: 'Código y nombre son obligatorios' });

        const [result] = await pool.query(`
            INSERT INTO proveedores (codigo, nombre, contacto_principal, telefono, email, direccion)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [codigo, nombre, contacto_principal, telefono, email, direccion]);

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'CREAR', 'proveedores', ?, ?, ?)
        `, [req.user.cedula, codigo, `Agregó proveedor ${nombre}`, req.ip]);

        const [nuevo] = await pool.query('SELECT * FROM proveedores WHERE id_proveedor = ?', [result.insertId]);
        res.status(201).json(nuevo[0]);
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'El código ya existe' });
        }
        console.error(err);
        res.status(500).json({ error: 'Error al crear proveedor' });
    }
});

// PUT /api/proveedores/:id - Actualizar
router.put('/:id', requireAction('proveedores', 'editar'), async (req, res) => {
    try {
        const { nombre, contacto_principal, telefono, email, direccion } = req.body;
        const [result] = await pool.query(`
            UPDATE proveedores SET nombre=?, contacto_principal=?, telefono=?, email=?, direccion=?
            WHERE codigo=? OR id_proveedor=?
        `, [nombre, contacto_principal, telefono, email, direccion, req.params.id, req.params.id]);

        if (result.affectedRows === 0) return res.status(404).json({ error: 'Proveedor no encontrado' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'EDITAR', 'proveedores', ?, ?, ?)
        `, [req.user.cedula, req.params.id, `Editó proveedor`, req.ip]);

        const [upd] = await pool.query('SELECT * FROM proveedores WHERE codigo = ? OR id_proveedor = ?', [req.params.id, req.params.id]);
        res.json(upd[0]);
    } catch (err) {
        res.status(500).json({ error: 'Error al actualizar proveedor' });
    }
});

// DELETE /api/proveedores/:id - Desactivar (borrado lógico)
router.delete('/:id', async (req, res) => {
    try {
        const [result] = await pool.query('UPDATE proveedores SET activo = FALSE WHERE codigo = ? OR id_proveedor = ?', [req.params.id, req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Proveedor no encontrado' });

        await pool.query(`
            INSERT INTO auditoria (cedula_usuario, accion, tabla_afectada, id_registro, detalles, ip_origen)
            VALUES (?, 'ELIMINAR', 'proveedores', ?, ?, ?)
        `, [req.user.cedula, req.params.id, `Desactivó proveedor`, req.ip]);

        res.json({ message: 'Proveedor desactivado' });
    } catch (err) {
        res.status(500).json({ error: 'Error al eliminar proveedor' });
    }
});

module.exports = router;
