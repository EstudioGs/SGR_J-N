// ============================================================
// MIDDLEWARE: Autenticación JWT y Control de Acceso por Rol
// ============================================================

const jwt = require('jsonwebtoken');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'jn31_secret_default';

// ============================================================
// MATRIZ DE PERMISOS
// Define qué rol puede acceder a qué módulo y qué acciones
// ============================================================
const ACCESS = {
    inicio: {
        'SuperUsuario':                    { access: true },
        'Gerente de Proyectos':            { access: true },
        'Director Regional / Presidente':  { access: true },
        'Gerente de Operaciones':          { access: true },
        'Especialista de Compra':          { access: true },
        'Personal Designado':              { access: true },
    },
    usuarios: {
        'SuperUsuario': { access: true, actions: ['listar','agregar','ver','editar','eliminar'] },
    },
    solicitudes: {
        'SuperUsuario':                    { access: true, actions: ['listar','agregar','ver','editar','eliminar'] },
        'Gerente de Proyectos':            { access: true, actions: ['listar','agregar','ver','editar','eliminar'] },
        'Director Regional / Presidente':  { access: true, actions: ['agregar'] },
        'Gerente de Operaciones':          { access: true, actions: ['listar','agregar','ver','editar','eliminar'] },
        'Especialista de Compra':          { access: true, actions: ['listar','agregar','ver','editar','eliminar'] },
        'Personal Designado':              { access: true, actions: ['agregar'] },
    },
    cotizacion: {
        'SuperUsuario':                    { access: true, actions: ['listar','ver','aprobar'] },
        'Gerente de Proyectos':            { access: true, actions: ['listar','elaborar','ver','aprobar'] },
        'Especialista de Compra':          { access: true, actions: ['listar','elaborar','ver','aprobar'] },
    },
    recursos: {
        // Exclusivo del Director Regional / Presidente
        'Director Regional / Presidente':  { access: true, actions: ['listar','ver','aprobar','rechazar'] },
    },
    proveedores: {
        'SuperUsuario':                    { access: true, actions: ['listar','ver'] },
        'Gerente de Proyectos':            { access: true, actions: ['listar','ver','editar'] },
        'Especialista de Compra':          { access: true, actions: ['listar','ver','editar'] },
    },
};

// ============================================================
// Verifica si un rol tiene acceso a un módulo
// ============================================================
function hasAccess(rol, modulo) {
    return !!(ACCESS[modulo] && ACCESS[modulo][rol] && ACCESS[modulo][rol].access);
}

// ============================================================
// Verifica si un rol puede realizar una acción específica
// ============================================================
function canDo(rol, modulo, action) {
    const m = ACCESS[modulo] && ACCESS[modulo][rol];
    if (!m || !m.access) return false;
    if (!m.actions) return true;
    return m.actions.includes(action);
}

// ============================================================
// Middleware: autenticar token JWT
// ============================================================
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // "Bearer TOKEN"

    if (!token) {
        return res.status(401).json({ error: 'Token de acceso requerido' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Token inválido o expirado' });
        }
        req.user = user; // { cedula, usuario, rol, nombre, ... }
        next();
    });
}

// ============================================================
// Middleware: requerir acceso a un módulo específico
// ============================================================
function requireModule(modulo) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'No autenticado' });
        }
        if (!hasAccess(req.user.rol, modulo)) {
            return res.status(403).json({ 
                error: `Acceso denegado al módulo: ${modulo}`,
                rol: req.user.rol
            });
        }
        next();
    };
}

// ============================================================
// Middleware: requerir acción específica en un módulo
// ============================================================
function requireAction(modulo, action) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'No autenticado' });
        }
        if (!canDo(req.user.rol, modulo, action)) {
            return res.status(403).json({ 
                error: `Su rol no tiene permiso para: ${action} en ${modulo}`,
                rol: req.user.rol
            });
        }
        next();
    };
}

// ============================================================
// Generar un token JWT para un usuario
// ============================================================
function generateToken(user) {
    return jwt.sign(
        { 
            cedula: user.cedula, 
            usuario: user.usuario, 
            rol: user.rol, 
            nombre: user.nombre,
            nombreCompleto: user.nombre_completo
        },
        JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRATION || '8h' }
    );
}

module.exports = {
    ACCESS,
    hasAccess,
    canDo,
    authenticateToken,
    requireModule,
    requireAction,
    generateToken
};
